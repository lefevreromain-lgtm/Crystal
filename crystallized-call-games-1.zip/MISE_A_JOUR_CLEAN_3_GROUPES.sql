-- CRYSTALLIZED CALL CLEAN 3
-- Nettoie les anciens groupes en double, empêche d'en recréer,
-- et ajoute Quitter / Supprimer un groupe.
-- À exécuter UNE SEULE FOIS dans Supabase > SQL Editor > New query.

-- 1) Garder un seul groupe par nom normalisé.
-- On conserve le plus ancien groupe et on supprime les doublons suivants.
do $$
declare
  r record;
begin
  for r in
    select id
    from (
      select
        id,
        row_number() over (
          partition by lower(regexp_replace(trim(coalesce(name,'')), '\s+', ' ', 'g'))
          order by created_at asc, id asc
        ) as rn
      from public.conversations
      where type='group'
    ) x
    where x.rn > 1
  loop
    delete from public.conversations where id=r.id;
  end loop;
end $$;

-- 2) Index unique : impossible de créer deux groupes avec le même nom
-- même avec des majuscules ou espaces différents.
create unique index if not exists conversations_unique_group_name_normalized
on public.conversations (
  lower(regexp_replace(trim(coalesce(name,'')), '\s+', ' ', 'g'))
)
where type='group';

-- 3) Quitter un groupe.
create or replace function public.leave_group(group_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  member_count integer;
  owner_count integer;
begin
  if auth.uid() is null then
    raise exception 'Non connecté';
  end if;

  if not exists (
    select 1 from public.conversation_members
    where conversation_id=group_id and user_id=auth.uid()
  ) then
    raise exception 'Vous ne faites pas partie de ce groupe';
  end if;

  select count(*) into member_count
  from public.conversation_members
  where conversation_id=group_id;

  if member_count <= 1 then
    delete from public.conversations where id=group_id;
    return;
  end if;

  -- Si le propriétaire part et qu'il n'y a pas d'autre owner,
  -- transférer le rôle à un autre membre.
  if exists (
    select 1 from public.conversation_members
    where conversation_id=group_id
      and user_id=auth.uid()
      and role='owner'
  ) then
    select count(*) into owner_count
    from public.conversation_members
    where conversation_id=group_id
      and role='owner'
      and user_id<>auth.uid();

    if owner_count=0 then
      update public.conversation_members
      set role='owner'
      where conversation_id=group_id
        and user_id=(
          select user_id
          from public.conversation_members
          where conversation_id=group_id
            and user_id<>auth.uid()
          order by joined_at asc
          limit 1
        );
    end if;
  end if;

  delete from public.conversation_members
  where conversation_id=group_id
    and user_id=auth.uid();
end;
$$;

grant execute on function public.leave_group(uuid) to authenticated;

-- 4) Supprimer un groupe : uniquement le propriétaire.
create or replace function public.delete_group(group_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then
    raise exception 'Non connecté';
  end if;

  if not exists (
    select 1
    from public.conversation_members
    where conversation_id=group_id
      and user_id=auth.uid()
      and role='owner'
  ) then
    raise exception 'Seul le propriétaire peut supprimer ce groupe';
  end if;

  if not exists (
    select 1 from public.conversations
    where id=group_id and type='group'
  ) then
    raise exception 'Groupe introuvable';
  end if;

  delete from public.conversations where id=group_id;
end;
$$;

grant execute on function public.delete_group(uuid) to authenticated;

select 'CLEAN 3 GROUPES OK' as resultat;
