(() => {
'use strict';

const SUPABASE_URL = 'https://mumlzlongsqzoelqcipo.supabase.co';
const SUPABASE_KEY = 'sb_publishable_qAcpXUEyfJXoKmfIjkcOWg_XL7QEDp5';

const sb = supabase.createClient(SUPABASE_URL, SUPABASE_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storage: window.localStorage
  }
});

const $ = id => document.getElementById(id);

const state = {
  session: null,
  profile: null,
  friends: [],
  conversations: [],
  activeConversation: null,
  activeMembers: [],
  globalChannel: null,
  chatChannel: null,
  selectedMessage: null,
  callInbox: null,
  callChannel: null,
  pc: null,
  localStream: null,
  incomingCall: null,
  currentCallId: null,
  callStartedAt: 0,
  callClock: null,
  muted: false,
  groupCallId: null,
  groupCallChannel: null,
  groupPeers: new Map(),
  recorder: null,
  recorderStream: null,
  recorderChunks: [],
  gameInvites: [],
  activeGame: null,
  gameChannel: null,
  gameBusy: false
};

const REMEMBERED_ACCOUNTS_KEY = 'cc_remembered_accounts_v1';

function normalizeGroupName(name=''){
  return name.trim().toLocaleLowerCase('fr-FR').replace(/\s+/g,' ');
}

function closeActiveConversation(){
  state.activeConversation = null;
  state.activeMembers = [];
  if(state.chatChannel){
    sb.removeChannel(state.chatChannel);
    state.chatChannel = null;
  }
  hide($('chatView'));
  show($('emptyState'));
  $('chat').classList.remove('open');
  hide($('groupActions'));
}


const esc = (v='') => String(v).replace(/[&<>"']/g, c => ({
  '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
}[c]));
const initials = (name='?') =>
  name.trim().split(/\s+/).map(x=>x[0]).join('').slice(0,2).toUpperCase() || '?';

function show(el){ el?.classList.remove('hidden'); }
function hide(el){ el?.classList.add('hidden'); }

function setAvatar(el, profile, fallback='?'){
  if(!el) return;
  if(profile?.avatar_url) el.innerHTML = `<img src="${esc(profile.avatar_url)}" alt="">`;
  else el.textContent = initials(profile?.username || fallback);
}

function authNote(message='', ok=false){
  $('authMessage').textContent = message;
  $('authMessage').classList.toggle('ok', !!ok);
}
function groupNote(message='', ok=false){
  $('groupMessage').textContent = message;
  $('groupMessage').classList.toggle('ok', !!ok);
}

function getRememberedAccounts(){
  try{
    const value = JSON.parse(localStorage.getItem(REMEMBERED_ACCOUNTS_KEY) || '[]');
    return Array.isArray(value) ? value.slice(0,8) : [];
  }catch{
    return [];
  }
}
function rememberAccount({email, username, avatar_url}){
  if(!email) return;
  const accounts = getRememberedAccounts()
    .filter(a => (a.email || '').toLowerCase() !== email.toLowerCase());

  accounts.unshift({
    email,
    username: username || email.split('@')[0],
    avatar_url: avatar_url || '',
    saved_at: Date.now()
  });

  localStorage.setItem(REMEMBERED_ACCOUNTS_KEY, JSON.stringify(accounts.slice(0,8)));
  renderRememberedAccounts();
}
function renderRememberedAccounts(){
  const box = $('rememberedAccounts');
  const wrap = $('rememberedBox');
  if(!box || !wrap) return;

  const accounts = getRememberedAccounts();
  box.innerHTML = '';
  wrap.classList.toggle('hidden', !accounts.length);

  accounts.forEach(account => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'rememberedAccount';
    btn.innerHTML = `
      <div class="avatar">${account.avatar_url ? `<img src="${esc(account.avatar_url)}" alt="">` : initials(account.username)}</div>
      <div class="acctText">
        <strong>${esc(account.username)}</strong>
        <small>${esc(account.email)}</small>
      </div>`;
    btn.onclick = () => {
      $('tabLogin').click();
      $('loginEmail').value = account.email;
      $('loginPassword').value = '';
      $('loginPassword').focus();
    };
    box.appendChild(btn);
  });
}

function lastSeenKey(cid){
  return `cc_last_seen_${state.session?.user?.id || 'x'}_${cid}`;
}
function getLastSeen(cid){
  return localStorage.getItem(lastSeenKey(cid)) || '1970-01-01T00:00:00.000Z';
}
function setLastSeen(cid){
  localStorage.setItem(lastSeenKey(cid), new Date().toISOString());
}

function showAuth(){
  hide($('loading'));
  hide($('app'));
  show($('auth'));
  renderRememberedAccounts();
}
function showApp(){
  hide($('loading'));
  hide($('auth'));
  show($('app'));
}

async function boot(){
  try{
    const {data,error} = await sb.auth.getSession();
    if(error) throw error;
    state.session = data.session;

    if(state.session) await enterApp();
    else showAuth();
  }catch(e){
    console.error('BOOT',e);
    showAuth();
  }
}

sb.auth.onAuthStateChange(async(event,session)=>{
  state.session = session;

  if(session && ['SIGNED_IN','TOKEN_REFRESHED','INITIAL_SESSION'].includes(event)){
    if($('app').classList.contains('hidden')) await enterApp();
  }

  if(!session && event === 'SIGNED_OUT'){
    cleanupChannels();
    state.profile = null;
    state.friends = [];
    state.conversations = [];
    state.activeConversation = null;
    showAuth();
  }
});

async function ensureProfile(){
  const uid = state.session.user.id;
  let {data,error} = await sb.from('profiles').select('*').eq('id',uid).maybeSingle();

  if(!data && !error){
    const username = state.session.user.user_metadata?.username || ('user_' + uid.slice(0,8));
    const created = await sb.from('profiles')
      .insert({id:uid,username})
      .select('*')
      .single();
    data = created.data;
    error = created.error;
  }

  if(error){
    console.error('PROFILE',error);
    state.profile = null;
    return;
  }
  state.profile = data;
}

async function enterApp(){
  if(!state.session) return showAuth();

  await ensureProfile();
  if(!state.profile) return showAuth();

  showApp();

  $('myName').textContent = state.profile.username;
  setAvatar($('myAvatar'),state.profile,state.profile.username);

  rememberAccount({
    email: state.session.user.email,
    username: state.profile.username,
    avatar_url: state.profile.avatar_url
  });

  await Promise.all([
    loadFriendRequests(),
    loadFriends(),
    loadConversations(),
    loadGameInvites()
  ]);

  renderGameFriends();
  subscribeGlobal();
}

function setupTabs(){
  $('tabLogin').onclick = () => {
    $('tabLogin').classList.add('active');
    $('tabSignup').classList.remove('active');
    show($('loginForm'));
    hide($('signupForm'));
    authNote('');
  };

  $('tabSignup').onclick = () => {
    $('tabSignup').classList.add('active');
    $('tabLogin').classList.remove('active');
    show($('signupForm'));
    hide($('loginForm'));
    authNote('');
  };
}

$('loginForm').onsubmit = async e => {
  e.preventDefault();
  authNote('Connexion…',true);

  const email = $('loginEmail').value.trim();
  const password = $('loginPassword').value;

  const {data,error} = await sb.auth.signInWithPassword({email,password});
  if(error) return authNote('E-mail ou mot de passe incorrect.');

  state.session = data.session;
  await enterApp();
};

$('signupForm').onsubmit = async e => {
  e.preventDefault();

  const email = $('signupEmail').value.trim();
  const username = $('signupUsername').value.trim();
  const password = $('signupPassword').value;

  if(!/^[A-Za-z0-9_-]{3,20}$/.test(username)){
    return authNote('Pseudo : 3 à 20 caractères, lettres, chiffres, _ ou -.');
  }

  authNote('Création du compte…',true);

  const {data,error} = await sb.auth.signUp({
    email,
    password,
    options:{data:{username}}
  });

  if(error) return authNote(error.message);

  if(data.session){
    state.session = data.session;
    await enterApp();
  }else{
    $('tabLogin').click();
    $('loginEmail').value = email;
    authNote('Compte créé. Ouvre l’e-mail de confirmation puis reviens te connecter.',true);
  }
};

$('logoutBtn').onclick = async () => {
  const ok = confirm(
    'Êtes-vous sûr de vouloir vous déconnecter ?\n\n' +
    'Votre compte restera proposé sur l’écran de connexion, mais il faudra retaper le mot de passe.'
  );
  if(!ok) return;

  cleanupChannels();
  await sb.auth.signOut();
};

function switchSideTab(name){
  document.querySelectorAll('.sideTab').forEach(btn => {
    btn.classList.toggle('active',btn.dataset.side === name);
  });

  $('sideChats').classList.toggle('hidden',name !== 'chats');
  $('sideAdd').classList.toggle('hidden',name !== 'add');
  $('sideRequests').classList.toggle('hidden',name !== 'requests');
  $('sideGames').classList.toggle('hidden',name !== 'games');

  if(name === 'requests') loadFriendRequests();
  if(name === 'add'){
    loadFriends();
    setTimeout(()=>$('userSearch').focus(),30);
  }
  if(name === 'chats') loadConversations();
  if(name === 'games'){
    loadFriends().then(renderGameFriends);
    loadGameInvites();
  }
}
document.querySelectorAll('.sideTab').forEach(btn => {
  btn.onclick = () => switchSideTab(btn.dataset.side);
});

async function loadFriendRequests(){
  const uid = state.session.user.id;
  const box = $('requestsList');
  box.innerHTML = '';

  const {data:reqs,error} = await sb
    .from('friend_requests')
    .select('id,sender_id,receiver_id,status,created_at')
    .eq('receiver_id',uid)
    .eq('status','pending')
    .order('created_at',{ascending:false});

  if(error){
    console.error('REQUESTS',error);
    $('requestTabDot').classList.add('hidden');
    $('requestCount').classList.add('hidden');
    box.innerHTML = `<div class="emptyFriendly">Aucune demande d'ami pour le moment.</div>`;
    return;
  }

  const count = reqs?.length || 0;
  $('requestTabDot').classList.toggle('hidden',count === 0);
  $('requestCount').textContent = count || '';
  $('requestCount').classList.toggle('hidden',count === 0);

  if(!count){
    box.innerHTML = `<div class="emptyFriendly">Aucune demande d'ami pour le moment.</div>`;
    return;
  }

  const ids = [...new Set(reqs.map(r=>r.sender_id))];
  const {data:profiles} = await sb
    .from('profiles')
    .select('id,username,avatar_url')
    .in('id',ids);

  const pmap = Object.fromEntries((profiles || []).map(p=>[p.id,p]));

  reqs.forEach(req=>{
    const p = pmap[req.sender_id] || {username:'Utilisateur'};

    const row = document.createElement('div');
    row.className = 'row';
    row.innerHTML = `
      <div class="avatar">${p.avatar_url ? `<img src="${esc(p.avatar_url)}">` : initials(p.username)}</div>
      <div class="rowText">
        <strong>${esc(p.username)}</strong>
        <small>Demande reçue</small>
      </div>
      <div class="rowActions">
        <button class="miniBtn accept">Accepter</button>
        <button class="miniBtn reject">Refuser</button>
      </div>`;

    row.querySelector('.accept').onclick = async () => {
      row.querySelectorAll('button').forEach(b=>b.disabled=true);

      const {error:e} = await sb.rpc('accept_friend_request',{request_id:req.id});
      if(e){
        row.querySelectorAll('button').forEach(b=>b.disabled=false);
        return alert('Impossible d’accepter : ' + e.message);
      }

      // Crée/ouvre immédiatement la discussion, donc le nouveau contact apparaît tout de suite.
      const privateResult = await sb.rpc('create_or_get_private_conversation',{
        other_user_id:req.sender_id
      });
      if(privateResult.error) console.warn('PRIVATE AFTER ACCEPT',privateResult.error);

      await Promise.all([
        loadFriendRequests(),
        loadFriends(),
        loadConversations()
      ]);

      switchSideTab('chats');
    };

    row.querySelector('.reject').onclick = async () => {
      row.querySelectorAll('button').forEach(b=>b.disabled=true);

      let {error:e} = await sb
        .from('friend_requests')
        .update({status:'rejected'})
        .eq('id',req.id)
        .eq('receiver_id',uid);

      if(e){
        const del = await sb
          .from('friend_requests')
          .delete()
          .eq('id',req.id)
          .eq('receiver_id',uid);
        e = del.error;
      }

      if(e){
        row.querySelectorAll('button').forEach(b=>b.disabled=false);
        return alert('Impossible de refuser : ' + e.message);
      }

      await loadFriendRequests();
    };

    box.appendChild(row);
  });
}

async function loadFriends(){
  const uid = state.session.user.id;

  const {data:links,error} = await sb
    .from('friendships')
    .select('user_one,user_two')
    .or(`user_one.eq.${uid},user_two.eq.${uid}`);

  if(error){
    console.error('FRIENDS',error);
    state.friends = [];
    return;
  }

  const ids = [...new Set(
    (links || []).map(x => x.user_one === uid ? x.user_two : x.user_one)
  )];

  if(!ids.length){
    state.friends = [];
    return;
  }

  const {data:profiles,error:pe} = await sb
    .from('profiles')
    .select('id,username,avatar_url,bio')
    .in('id',ids);

  if(pe){
    console.error('FRIEND PROFILES',pe);
    state.friends = [];
    return;
  }

  state.friends = (profiles || [])
    .sort((a,b)=>(a.username || '').localeCompare(b.username || ''));
}

async function searchUsers(){
  const q = $('userSearch').value.trim();
  const box = $('searchResults');
  box.innerHTML = '';

  if(q.length < 2){
    box.innerHTML = `<div class="emptyFriendly">Écris au moins 2 caractères du pseudo.</div>`;
    return;
  }

  const {data,error} = await sb
    .from('profiles')
    .select('id,username,avatar_url,bio')
    .ilike('username',`%${q}%`)
    .neq('id',state.session.user.id)
    .order('username')
    .limit(12);

  if(error || !data?.length){
    if(error) console.error('SEARCH',error);
    box.innerHTML = `<div class="emptyFriendly">Aucun utilisateur trouvé avec ce pseudo.</div>`;
    return;
  }

  const uid = state.session.user.id;
  const targetIds = data.map(p=>p.id);
  const pendingResult = await sb
    .from('friend_requests')
    .select('receiver_id')
    .eq('sender_id',uid)
    .eq('status','pending')
    .in('receiver_id',targetIds);

  const pendingByTarget = new Set(
    (pendingResult.data || []).map(r=>r.receiver_id)
  );

  data.forEach(p=>{
    const isFriend = state.friends.some(f=>f.id===p.id);
    const isPending = pendingByTarget.has(p.id);

    const row = document.createElement('div');
    row.className = 'row friendFound';
    row.innerHTML = `
      <div class="avatar">${p.avatar_url ? `<img src="${esc(p.avatar_url)}">` : initials(p.username)}</div>
      <div class="rowText">
        <strong>${esc(p.username)}</strong>
        <small class="${isPending ? 'requestWaiting' : ''}">
          ${isFriend ? 'Déjà dans tes contacts' : isPending ? 'Demande en attente' : 'Pas encore ami'}
        </small>
      </div>
      <button class="miniBtn actionBtn" ${isPending ? 'disabled' : ''}>
        ${isFriend ? 'Message' : isPending ? 'Envoyée ✓' : 'Ajouter'}
      </button>`;

    const btn = row.querySelector('.actionBtn');

    btn.onclick = async () => {
      if(isFriend){
        await openPrivateConversation(p);
        switchSideTab('chats');
        return;
      }
      if(isPending) return;

      btn.disabled = true;
      btn.textContent = 'Envoi…';

      const {error:e} = await sb.from('friend_requests').insert({
        sender_id:uid,
        receiver_id:p.id,
        status:'pending'
      });

      if(e){
        if(/duplicate|unique/i.test(e.message || '')){
          btn.textContent = 'Envoyée ✓';
          row.querySelector('small').textContent = 'Demande en attente';
          row.querySelector('small').classList.add('requestWaiting');
          return;
        }

        btn.disabled = false;
        btn.textContent = 'Ajouter';
        return alert('Impossible d’envoyer la demande : ' + e.message);
      }

      btn.textContent = 'Envoyée ✓';
      row.querySelector('small').textContent = 'Demande en attente';
      row.querySelector('small').classList.add('requestWaiting');
    };

    box.appendChild(row);
  });
}
$('searchBtn').onclick = searchUsers;
$('userSearch').onkeydown = e => {
  if(e.key === 'Enter'){
    e.preventDefault();
    searchUsers();
  }
};

async function fetchConversations(ids){
  let result = await sb
    .from('conversations')
    .select('id,type,name,group_avatar_url,created_at,created_by')
    .in('id',ids)
    .order('created_at',{ascending:false});

  if(result.error && /group_avatar_url/i.test(result.error.message || '')){
    result = await sb
      .from('conversations')
      .select('id,type,name,created_at,created_by')
      .in('id',ids)
      .order('created_at',{ascending:false});
  }

  return result;
}

async function loadConversations(){
  const uid = state.session.user.id;
  const box = $('conversationList');

  // On garde la liste actuelle visible pendant le rechargement.
  // Au tout premier affichage seulement, on montre 3 lignes fixes au lieu
  // d'ajouter les contacts un par un.
  if(!box.children.length){
    box.innerHTML = `<div class="loadingList">
      <div class="loadingRow"></div>
      <div class="loadingRow"></div>
      <div class="loadingRow"></div>
    </div>`;
  }

  const {data:memberships,error} = await sb
    .from('conversation_members')
    .select('conversation_id,user_id,role')
    .eq('user_id',uid);

  if(error){
    console.error('CONVERSATIONS MEMBERSHIP',error);
    box.innerHTML = `<div class="emptyFriendly">Tu n'as pas encore d'ami ou de discussion.<br>Va dans <b>Ajouter</b> pour chercher un pseudo.</div>`;
    $('messagesTabDot').classList.add('hidden');
    return;
  }

  const ids = [...new Set((memberships || []).map(m=>m.conversation_id))];

  if(!ids.length){
    state.conversations = [];
    box.innerHTML = `<div class="emptyFriendly">Tu n'as pas encore d'ami ou de discussion.<br>Va dans <b>Ajouter</b> pour chercher un pseudo.</div>`;
    $('messagesTabDot').classList.add('hidden');
    return;
  }

  const convoResult = await fetchConversations(ids);
  if(convoResult.error){
    console.error('CONVERSATIONS DATA',convoResult.error);
    return;
  }

  const rawConversations = convoResult.data || [];

  // Une seule requête pour TOUS les membres de TOUTES les discussions.
  const {data:allMembers,error:membersError} = await sb
    .from('conversation_members')
    .select('conversation_id,user_id,role')
    .in('conversation_id',ids);

  if(membersError){
    console.error('ALL MEMBERS',membersError);
    return;
  }

  const profileIds = [...new Set((allMembers || []).map(m=>m.user_id))];
  let allProfiles = [];
  if(profileIds.length){
    const pr = await sb
      .from('profiles')
      .select('id,username,avatar_url')
      .in('id',profileIds);
    allProfiles = pr.data || [];
  }

  const profileMap = Object.fromEntries(allProfiles.map(p=>[p.id,p]));
  const membersByConversation = {};
  (allMembers || []).forEach(m=>{
    (membersByConversation[m.conversation_id] ||= []).push({
      ...m,
      profile:profileMap[m.user_id]
    });
  });

  // Supprime visuellement les anciens groupes doublons.
  const seenGroupNames = new Set();
  const visibleConversations = rawConversations.filter(convo=>{
    if(convo.type !== 'group') return true;
    const key = normalizeGroupName(convo.name || 'Groupe');
    if(seenGroupNames.has(key)) return false;
    seenGroupNames.add(key);
    return true;
  });

  // Tous les compteurs non lus sont calculés en parallèle.
  const unreadValues = await Promise.all(
    visibleConversations.map(c=>countUnread(c.id))
  );

  let totalUnread = 0;
  const prepared = visibleConversations.map((convo,index)=>{
    const members = membersByConversation[convo.id] || [];
    let info;

    if(convo.type === 'group'){
      info = {
        title:convo.name || 'Groupe',
        subtitle:`${members.length} membre${members.length > 1 ? 's' : ''}`,
        avatarHtml:convo.group_avatar_url ? `<img src="${esc(convo.group_avatar_url)}">` : '👥',
        members
      };
    }else{
      const other = members.find(m=>m.user_id !== uid)?.profile;
      info = {
        title:other?.username || 'Discussion',
        subtitle:'Discussion privée',
        avatarHtml:other?.avatar_url ? `<img src="${esc(other.avatar_url)}">` : initials(other?.username || '?'),
        members
      };
    }

    const unread = unreadValues[index] || 0;
    totalUnread += unread;
    return {...convo,_display:info,_unread:unread};
  });

  state.conversations = prepared;

  // Un seul remplacement de l'écran : pas d'apparition 1 par 1, pas de défilement.
  const fragment = document.createDocumentFragment();
  prepared.forEach(convo=>{
    const info = convo._display;
    const row = document.createElement('button');
    row.className = 'row' + (state.activeConversation?.id === convo.id ? ' active' : '');
    row.dataset.cid = convo.id;
    row.innerHTML = `
      <div class="avatar">${info.avatarHtml}</div>
      <div class="rowText">
        <strong>${esc(info.title)}</strong>
        <small>${esc(info.subtitle)}</small>
      </div>
      ${convo._unread ? `<span class="unreadDot">${convo._unread > 99 ? '99+' : convo._unread}</span>` : ''}`;
    row.onclick = ()=>openConversation(convo.id);
    fragment.appendChild(row);
  });

  box.replaceChildren(fragment);
  $('messagesTabDot').classList.toggle('hidden',totalUnread === 0);
}

async function getConversationDisplay(convo){
  if(convo?._display) return convo._display;

  const {data:members} = await sb
    .from('conversation_members')
    .select('user_id,role')
    .eq('conversation_id',convo.id);

  const ids = [...new Set((members || []).map(m=>m.user_id))];
  let profiles = [];
  if(ids.length){
    const r = await sb.from('profiles').select('id,username,avatar_url').in('id',ids);
    profiles = r.data || [];
  }
  const pmap = Object.fromEntries(profiles.map(p=>[p.id,p]));
  const enriched = (members || []).map(m=>({...m,profile:pmap[m.user_id]}));

  if(convo.type === 'group'){
    return {
      title:convo.name || 'Groupe',
      subtitle:`${enriched.length} membre${enriched.length > 1 ? 's' : ''}`,
      avatarHtml:convo.group_avatar_url ? `<img src="${esc(convo.group_avatar_url)}">` : '👥',
      members:enriched
    };
  }

  const other = enriched.find(m=>m.user_id !== state.session.user.id)?.profile;
  return {
    title:other?.username || 'Discussion',
    subtitle:'Discussion privée',
    avatarHtml:other?.avatar_url ? `<img src="${esc(other.avatar_url)}">` : initials(other?.username || '?'),
    members:enriched
  };
}

async function countUnread(conversationId){
  const lastSeen = getLastSeen(conversationId);

  let result = await sb
    .from('messages')
    .select('id',{count:'exact',head:true})
    .eq('conversation_id',conversationId)
    .neq('sender_id',state.session.user.id)
    .gt('created_at',lastSeen)
    .is('deleted_at',null);

  if(result.error && /deleted_at/i.test(result.error.message || '')){
    result = await sb
      .from('messages')
      .select('id',{count:'exact',head:true})
      .eq('conversation_id',conversationId)
      .neq('sender_id',state.session.user.id)
      .gt('created_at',lastSeen);
  }

  return result.count || 0;
}

async function openPrivateConversation(profile){
  const {data,error} = await sb.rpc(
    'create_or_get_private_conversation',
    {other_user_id:profile.id}
  );

  if(error) return alert('Impossible d’ouvrir la discussion : ' + error.message);

  await loadConversations();
  await openConversation(data);
}

async function openConversation(id){
  let convo = state.conversations.find(c=>c.id===id);

  if(!convo){
    let result = await sb
      .from('conversations')
      .select('id,type,name,group_avatar_url,created_at,created_by')
      .eq('id',id)
      .single();

    if(result.error && /group_avatar_url/i.test(result.error.message || '')){
      result = await sb
        .from('conversations')
        .select('id,type,name,created_at,created_by')
        .eq('id',id)
        .single();
    }
    convo = result.data;
  }

  if(!convo) return;

  if(!convo._display) convo._display = await getConversationDisplay(convo);

  state.activeConversation = convo;
  state.activeMembers = convo._display.members || [];

  setLastSeen(convo.id);

  $('chatName').textContent = convo._display.title;
  $('chatSub').textContent = convo._display.subtitle;
  $('chatAvatar').innerHTML = convo._display.avatarHtml;

  if(convo.type === 'group'){
    show($('groupActions'));
    const myMembership = (convo._display.members || []).find(m => m.user_id === state.session.user.id);
    const canDelete = myMembership?.role === 'owner' || convo.created_by === state.session.user.id;
    $('deleteGroupBtn').classList.toggle('hidden', !canDelete);
  }else{
    hide($('groupActions'));
  }

  hide($('emptyState'));
  show($('chatView'));
  $('chat').classList.add('open');

  await loadMessages();
  subscribeChat(convo.id);
  await loadConversations();
}

async function loadMessages(){
  const convo = state.activeConversation;
  if(!convo) return;

  const box = $('messages');

  const {data:msgs,error} = await sb
    .from('messages')
    .select('*')
    .eq('conversation_id',convo.id)
    .order('created_at',{ascending:true});

  if(error){
    console.error('MESSAGES',error);
    box.innerHTML = `<div class="emptyFriendly">Impossible d'afficher les messages pour le moment.</div>`;
    return;
  }

  const senderIds = [...new Set((msgs || []).map(m=>m.sender_id).filter(Boolean))];
  let profiles = [];

  if(senderIds.length){
    const p = await sb
      .from('profiles')
      .select('id,username,avatar_url')
      .in('id',senderIds);
    profiles = p.data || [];
  }

  const pmap = Object.fromEntries(profiles.map(p=>[p.id,p]));
  box.innerHTML = '';

  if(!msgs?.length){
    box.innerHTML = `<div class="emptyFriendly">Envoie le premier message.</div>`;
  }

  (msgs || []).forEach(m=>{
    const mine = m.sender_id === state.session.user.id;
    const bubble = document.createElement('div');
    bubble.className = 'bubble ' + (mine ? 'mine' : 'other');
    bubble.dataset.mid = m.id;

    const sender = pmap[m.sender_id];
    const author = convo.type === 'group' && !mine
      ? `<div class="author">${esc(sender?.username || 'Utilisateur')}</div>`
      : '';

    const deleted = !!m.deleted_at;
    let body;
    if(deleted){
      body = `<span class="deleted">Message supprimé</span>`;
    }else if(m.message_type === 'image' && m.media_url){
      body = `<img class="msgImage" src="${esc(m.media_url)}" alt="Image" loading="lazy">`;
    }else if(m.message_type === 'voice' && m.media_url){
      body = `<audio controls preload="metadata" src="${esc(m.media_url)}"></audio>`;
    }else{
      body = esc(m.content || '');
    }

    const time = new Date(m.created_at).toLocaleTimeString(
      'fr-FR',
      {hour:'2-digit',minute:'2-digit'}
    );

    bubble.innerHTML = `
      ${author}
      ${body}
      <div class="msgMeta">
        ${time}${m.edited_at ? ' · modifié' : ''}
      </div>`;

    if(mine && !deleted){
      bubble.onclick = () => openMessageMenu(m);
    }

    box.appendChild(bubble);
  });

  setLastSeen(convo.id);
  box.scrollTop = box.scrollHeight;
}


async function uploadMedia(file,type,durationSeconds=null){
  const convo = state.activeConversation;
  if(!convo || !file) return;

  const ext = (file.name?.split('.').pop() || (type === 'voice' ? 'webm' : 'jpg'))
    .replace(/[^a-z0-9]/gi,'') || 'bin';
  const path = `${state.session.user.id}/${convo.id}/${crypto.randomUUID()}.${ext}`;

  const upload = await sb.storage
    .from('chat-media')
    .upload(path,file,{contentType:file.type,upsert:false});

  if(upload.error){
    alert('Envoi impossible pour le moment.');
    return;
  }

  const publicUrl = sb.storage.from('chat-media').getPublicUrl(path).data.publicUrl;

  const row = {
    conversation_id:convo.id,
    sender_id:state.session.user.id,
    message_type:type,
    media_url:publicUrl
  };
  if(durationSeconds) row.duration_seconds = durationSeconds;

  const inserted = await sb.from('messages').insert(row);
  if(inserted.error){
    alert('Le média n’a pas pu être envoyé.');
    return;
  }

  await loadMessages();
}

$('photoBtn').onclick = ()=>$('photoInput').click();
$('photoInput').onchange = async e=>{
  const file = e.target.files?.[0];
  e.target.value = '';
  if(file) await uploadMedia(file,'image');
};

$('voiceBtn').onclick = async()=>{
  if(state.recorder?.state === 'recording'){
    state.recorder.stop();
    return;
  }

  if(!window.isSecureContext){
    return alert('Les vocaux nécessitent la version HTTPS de l’application.');
  }

  try{
    state.recorderStream = await navigator.mediaDevices.getUserMedia({audio:true});
    state.recorderChunks = [];
    const startedAt = Date.now();

    const mime = ['audio/webm;codecs=opus','audio/webm','audio/mp4']
      .find(x=>window.MediaRecorder?.isTypeSupported?.(x));

    state.recorder = mime
      ? new MediaRecorder(state.recorderStream,{mimeType:mime})
      : new MediaRecorder(state.recorderStream);

    state.recorder.ondataavailable = e=>{
      if(e.data.size) state.recorderChunks.push(e.data);
    };

    state.recorder.onstop = async()=>{
      $('voiceBtn').classList.remove('recording');
      $('voiceBtn').textContent = '🎙️';

      state.recorderStream?.getTracks().forEach(t=>t.stop());

      const blob = new Blob(
        state.recorderChunks,
        {type:state.recorder.mimeType || 'audio/webm'}
      );
      const file = new File([blob],'vocal.webm',{type:blob.type});
      const duration = Math.max(1,Math.round((Date.now()-startedAt)/1000));

      state.recorder = null;
      state.recorderStream = null;
      state.recorderChunks = [];

      await uploadMedia(file,'voice',duration);
    };

    state.recorder.start(250);
    $('voiceBtn').classList.add('recording');
    $('voiceBtn').textContent = '⏹';

    setTimeout(()=>{
      if(state.recorder?.state === 'recording') state.recorder.stop();
    },60000);
  }catch(e){
    console.error('VOICE',e);
    alert('Autorise le microphone pour envoyer un vocal.');
  }
};

$('composer').onsubmit = async e => {
  e.preventDefault();

  const convo = state.activeConversation;
  const input = $('messageInput');
  const content = input.value.trim();

  if(!convo || !content) return;

  input.value = '';

  let {error} = await sb.from('messages').insert({
    conversation_id:convo.id,
    sender_id:state.session.user.id,
    message_type:'text',
    content
  });

  if(error && /message_type/i.test(error.message || '')){
    ({error} = await sb.from('messages').insert({
      conversation_id:convo.id,
      sender_id:state.session.user.id,
      content
    }));
  }

  if(error){
    input.value = content;
    return alert('Message non envoyé : ' + error.message);
  }

  await loadMessages();
};

$('messageInput').oninput = () => {
  const el = $('messageInput');
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight,130) + 'px';
};

function openMessageMenu(message){
  state.selectedMessage = message;
  show($('messageMenu'));
}
$('closeMessageMenuBtn').onclick = () => hide($('messageMenu'));

$('editMessageBtn').onclick = async () => {
  const m = state.selectedMessage;
  hide($('messageMenu'));
  if(!m) return;

  const value = prompt('Modifier le message :',m.content || '');
  if(value === null) return;

  const content = value.trim();
  if(!content) return;

  let {error} = await sb
    .from('messages')
    .update({
      content,
      edited_at:new Date().toISOString()
    })
    .eq('id',m.id)
    .eq('sender_id',state.session.user.id);

  if(error && /edited_at/i.test(error.message || '')){
    ({error} = await sb
      .from('messages')
      .update({content})
      .eq('id',m.id)
      .eq('sender_id',state.session.user.id));
  }

  if(error) return alert('Modification impossible : ' + error.message);
  await loadMessages();
};

$('deleteMessageBtn').onclick = async () => {
  const m = state.selectedMessage;
  hide($('messageMenu'));

  if(!m || !confirm('Supprimer ce message ?')) return;

  let {error} = await sb
    .from('messages')
    .update({
      content:'',
      deleted_at:new Date().toISOString()
    })
    .eq('id',m.id)
    .eq('sender_id',state.session.user.id);

  if(error){
    const del = await sb
      .from('messages')
      .delete()
      .eq('id',m.id)
      .eq('sender_id',state.session.user.id);
    error = del.error;
  }

  if(error) return alert('Suppression impossible : ' + error.message);
  await loadMessages();
};

function subscribeChat(conversationId){
  if(state.chatChannel) sb.removeChannel(state.chatChannel);

  state.chatChannel = sb
    .channel('clean2-chat-' + conversationId)
    .on(
      'postgres_changes',
      {
        event:'*',
        schema:'public',
        table:'messages',
        filter:`conversation_id=eq.${conversationId}`
      },
      async()=>{
        await loadMessages();
        await loadConversations();
      }
    )
    .subscribe();
}

function subscribeGlobal(){
  if(state.globalChannel) sb.removeChannel(state.globalChannel);

  const uid = state.session.user.id;

  state.globalChannel = sb
    .channel('clean4-call-inbox-' + uid)
    .on(
      'postgres_changes',
      {
        event:'*',
        schema:'public',
        table:'friend_requests',
        filter:`receiver_id=eq.${uid}`
      },
      async()=>{ await loadFriendRequests(); }
    )
    .on(
      'postgres_changes',
      {
        event:'*',
        schema:'public',
        table:'conversation_members',
        filter:`user_id=eq.${uid}`
      },
      async()=>{ await loadConversations(); }
    )
    .on(
      'postgres_changes',
      {
        event:'INSERT',
        schema:'public',
        table:'messages'
      },
      async payload => {
        if(payload.new?.sender_id === uid) return;

        if(payload.new?.conversation_id === state.activeConversation?.id){
          setLastSeen(payload.new.conversation_id);
          await loadMessages();
        }

        await loadConversations();
      }
    )
    .on('broadcast',{event:'incoming-call'},({payload})=>receiveIncomingCall(payload))
    .on('broadcast',{event:'game-invite'},()=>loadGameInvites())
    .on(
      'postgres_changes',
      {event:'*',schema:'public',table:'game_invites',filter:`receiver_id=eq.${uid}`},
      async()=>{ await loadGameInvites(); }
    )
    .on(
      'postgres_changes',
      {event:'UPDATE',schema:'public',table:'game_invites',filter:`sender_id=eq.${uid}`},
      async({new:invite})=>{
        if(invite.status === 'accepted' && invite.game_id){
          await openGame(invite.game_id);
        }
      }
    )
    .subscribe();
}

function cleanupChannels(){
  endAudioCall(false);
  if(state.globalChannel) sb.removeChannel(state.globalChannel);
  if(state.chatChannel) sb.removeChannel(state.chatChannel);
  if(state.gameChannel) sb.removeChannel(state.gameChannel);
  state.globalChannel = null;
  state.chatChannel = null;
  state.gameChannel = null;
  state.activeGame = null;
}

$('newGroupBtn').onclick = async () => {
  await loadFriends();

  const box = $('groupFriends');
  box.innerHTML = '';

  if(!state.friends.length){
    box.innerHTML = `
      <div class="emptyFriendly">
        Tu n'as pas encore d'ami.<br>
        Ajoute d'abord quelqu'un dans l'onglet <b>Ajouter</b>.
      </div>`;
  }else{
    state.friends.forEach(f=>{
      const label = document.createElement('label');
      label.className = 'checkRow';
      label.innerHTML = `
        <input type="checkbox" value="${f.id}">
        <div class="avatar">
          ${f.avatar_url ? `<img src="${esc(f.avatar_url)}">` : initials(f.username)}
        </div>
        <strong>${esc(f.username)}</strong>`;
      box.appendChild(label);
    });
  }

  $('groupName').value = '';
  groupNote('');
  show($('groupModal'));
};

$('closeGroupBtn').onclick = () => hide($('groupModal'));

$('createGroupBtn').onclick = async () => {
  const btn = $('createGroupBtn');
  if(btn.disabled) return;

  const name = $('groupName').value.trim();
  const memberIds = [...$('groupFriends').querySelectorAll('input:checked')]
    .map(x=>x.value);

  if(name.length < 2) return groupNote('Écris un nom de groupe.');

  const duplicateName = state.conversations.some(c =>
    c.type === 'group' && normalizeGroupName(c.name || '') === normalizeGroupName(name)
  );
  if(duplicateName) return groupNote('Un groupe avec ce nom existe déjà. Choisis un autre nom.');
  if(!memberIds.length) return groupNote('Choisis au moins un ami.');

  btn.disabled = true;
  btn.textContent = 'Création…';
  groupNote('Création du groupe…',true);

  try{
    const {data,error} = await sb.rpc('create_group_conversation',{
      group_name:name,
      member_ids:memberIds
    });

    if(error){
      console.error('CREATE GROUP',error);
      return groupNote('Le groupe n’a pas pu être créé. Réessaie dans quelques secondes.');
    }

    if(!data){
      return groupNote('Le groupe n’a pas pu être créé.');
    }

    hide($('groupModal'));
    switchSideTab('chats');

    await loadConversations();
    await openConversation(data);
  }finally{
    btn.disabled = false;
    btn.textContent = 'Créer le groupe';
  }
};


$('leaveGroupBtn').onclick = async () => {
  const convo = state.activeConversation;
  if(!convo || convo.type !== 'group') return;

  const ok = confirm(`Quitter le groupe "${convo.name || 'Groupe'}" ?`);
  if(!ok) return;

  const {error} = await sb.rpc('leave_group',{group_id:convo.id});
  if(error){ console.error('LEAVE GROUP',error); return alert('Impossible de quitter ce groupe pour le moment.'); }

  closeActiveConversation();
  await loadConversations();
};

$('deleteGroupBtn').onclick = async () => {
  const convo = state.activeConversation;
  if(!convo || convo.type !== 'group') return;

  const ok = confirm(
    `Supprimer définitivement le groupe "${convo.name || 'Groupe'}" ?\n\n` +
    `Le groupe et ses messages seront supprimés pour tout le monde.`
  );
  if(!ok) return;

  const {error} = await sb.rpc('delete_group',{group_id:convo.id});
  if(error){ console.error('DELETE GROUP',error); return alert('Impossible de supprimer ce groupe pour le moment.'); }

  closeActiveConversation();
  await loadConversations();
};



function gameOtherPlayer(game){
  if(!game || !state.session) return null;
  return game.player1 === state.session.user.id ? game.player2 : game.player1;
}

function getGameProfile(userId){
  if(userId === state.session?.user?.id) return state.profile;
  return state.friends.find(f=>f.id===userId) || null;
}

function playerCardHtml(userId, symbol=''){
  const p = getGameProfile(userId) || {username:'Joueur'};
  const avatar = p.avatar_url
    ? `<div class="avatar"><img src="${esc(p.avatar_url)}"></div>`
    : `<div class="avatar">${initials(p.username)}</div>`;
  return `${avatar}<div class="gamePlayerText"><strong>${esc(p.username)}</strong><small>${symbol}</small></div>`;
}

async function loadGameInvites(){
  if(!state.session) return;
  const uid = state.session.user.id;

  const {data,error} = await sb
    .from('game_invites')
    .select('id,sender_id,receiver_id,status,game_id,created_at')
    .eq('receiver_id',uid)
    .eq('status','pending')
    .order('created_at',{ascending:false});

  if(error){
    console.error('GAME INVITES',error);
    $('gameTabDot')?.classList.add('hidden');
    return;
  }

  state.gameInvites = data || [];
  $('gameTabDot')?.classList.toggle('hidden',state.gameInvites.length === 0);
  renderGameInvites();
}

function renderGameInvites(){
  const wrap = $('gameInvitesBox');
  const box = $('gameInvitesList');
  if(!wrap || !box) return;

  box.innerHTML = '';
  wrap.classList.toggle('hidden',state.gameInvites.length === 0);

  state.gameInvites.forEach(invite=>{
    const p = getGameProfile(invite.sender_id) || {username:'Un ami'};
    const row = document.createElement('div');
    row.className = 'row gameInviteRow';
    row.innerHTML = `
      <div class="avatar">${p.avatar_url ? `<img src="${esc(p.avatar_url)}">` : initials(p.username)}</div>
      <div class="rowText">
        <strong>${esc(p.username)}</strong>
        <small>veut jouer avec toi 🎮</small>
      </div>
      <div class="rowActions">
        <button class="miniBtn accept">Accepter</button>
        <button class="miniBtn reject">Refuser</button>
      </div>`;

    row.querySelector('.accept').onclick = async()=>{
      row.querySelectorAll('button').forEach(b=>b.disabled=true);
      const {data,error} = await sb.rpc('accept_game_invite',{invite_id:invite.id});
      if(error){
        console.error('ACCEPT GAME INVITE',error);
        row.querySelectorAll('button').forEach(b=>b.disabled=false);
        return alert("Impossible d'accepter cette partie.");
      }
      await loadGameInvites();
      await openGame(data);
    };

    row.querySelector('.reject').onclick = async()=>{
      row.querySelectorAll('button').forEach(b=>b.disabled=true);
      const {error} = await sb.rpc('reject_game_invite',{invite_id:invite.id});
      if(error){
        console.error('REJECT GAME INVITE',error);
        row.querySelectorAll('button').forEach(b=>b.disabled=false);
        return alert("Impossible de refuser cette invitation.");
      }
      await loadGameInvites();
    };

    box.appendChild(row);
  });
}

function renderGameFriends(){
  const box = $('gameFriendsList');
  if(!box) return;
  box.innerHTML = '';

  if(!state.friends.length){
    box.innerHTML = `<div class="emptyFriendly">Tu n'as pas encore d'ami à inviter.</div>`;
    return;
  }

  state.friends.forEach(friend=>{
    const row = document.createElement('div');
    row.className = 'row gameFriendRow';
    row.innerHTML = `
      <div class="avatar">${friend.avatar_url ? `<img src="${esc(friend.avatar_url)}">` : initials(friend.username)}</div>
      <div class="rowText">
        <strong>${esc(friend.username)}</strong>
        <small>Disponible pour une invitation</small>
      </div>
      <button class="playInviteBtn">Inviter</button>`;

    const btn = row.querySelector('.playInviteBtn');
    btn.onclick = async()=>{
      btn.disabled = true;
      btn.textContent = 'Envoyée ✓';

      const {data,error} = await sb.rpc('create_game_invite',{other_user_id:friend.id});
      if(error){
        console.error('CREATE GAME INVITE',error);
        btn.disabled = false;
        btn.textContent = 'Inviter';
        return alert("Impossible d'envoyer l'invitation.");
      }

      // Notification immédiate si l'autre a l'app ouverte.
      try{
        await sendGamePing(friend.id,'game-invite',{
          from:state.session.user.id,
          username:state.profile.username,
          invite_id:data
        });
      }catch{}
    };

    box.appendChild(row);
  });
}

async function sendGamePing(userId,event,payload){
  const ch = sb.channel('games-inbox-' + userId);
  await new Promise(resolve=>{
    ch.subscribe(status=>{
      if(status === 'SUBSCRIBED') resolve();
    });
  });
  await ch.send({type:'broadcast',event,payload});
  setTimeout(()=>sb.removeChannel(ch),400);
}

async function openGame(gameId){
  if(!gameId) return;

  const {data,error} = await sb
    .from('games')
    .select('*')
    .eq('id',gameId)
    .single();

  if(error || !data){
    console.error('OPEN GAME',error);
    return alert("La partie n'est plus disponible.");
  }

  state.activeGame = data;
  show($('gameScreen'));
  await renderGame();

  if(state.gameChannel) sb.removeChannel(state.gameChannel);
  state.gameChannel = sb
    .channel('game-' + gameId)
    .on(
      'postgres_changes',
      {event:'UPDATE',schema:'public',table:'games',filter:`id=eq.${gameId}`},
      ({new:updated})=>{
        state.activeGame = updated;
        renderGame();
      }
    )
    .subscribe();
}

function closeGameScreen(){
  hide($('gameScreen'));
  if(state.gameChannel){
    sb.removeChannel(state.gameChannel);
    state.gameChannel = null;
  }
  state.activeGame = null;
  state.gameBusy = false;
}

function boardArray(game){
  return Array.isArray(game?.board) ? game.board : [];
}

function renderGame(){
  const game = state.activeGame;
  if(!game) return;

  const me = state.session.user.id;
  const p1 = getGameProfile(game.player1) || {username:game.player1===me ? state.profile.username : 'Joueur 1'};
  const p2 = getGameProfile(game.player2) || {username:game.player2===me ? state.profile.username : 'Joueur 2'};

  const p1Symbol = game.game_type === 'morpion' ? '❌' : game.game_type === 'puissance4' ? '🔴' : 'Joueur 1';
  const p2Symbol = game.game_type === 'morpion' ? '⭕' : game.game_type === 'puissance4' ? '🟡' : 'Joueur 2';

  $('gamePlayer1').innerHTML = playerCardHtml(game.player1,p1Symbol);
  $('gamePlayer2').innerHTML = playerCardHtml(game.player2,p2Symbol);
  $('gamePlayer1').classList.toggle('meTurn',game.current_turn===game.player1 && game.status==='playing');
  $('gamePlayer2').classList.toggle('meTurn',game.current_turn===game.player2 && game.status==='playing');

  hide($('gameChoice'));
  hide($('ticTacToeWrap'));
  hide($('connect4Wrap'));
  hide($('gameResult'));
  $('abandonGameBtn').classList.toggle('hidden',game.status!=='playing');

  if(game.status === 'lobby'){
    $('gameTitle').textContent = 'Salon de jeu';
    $('gameStatus').textContent = 'Choisissez Morpion ou Puissance 4';
    show($('gameChoice'));
    return;
  }

  if(game.game_type === 'morpion'){
    $('gameTitle').textContent = 'Morpion';
  }else if(game.game_type === 'puissance4'){
    $('gameTitle').textContent = 'Puissance 4';
  }else{
    $('gameTitle').textContent = 'Partie';
  }

  if(game.status === 'playing'){
    const turnP = getGameProfile(game.current_turn);
    $('gameStatus').textContent =
      game.current_turn === me
        ? 'À toi de jouer !'
        : `Au tour de ${turnP?.username || "l'autre joueur"}`;

    if(game.game_type === 'morpion') renderTicTacToe();
    if(game.game_type === 'puissance4') renderConnect4();
    return;
  }

  if(game.status === 'finished'){
    if(game.game_type === 'morpion') renderTicTacToe();
    if(game.game_type === 'puissance4') renderConnect4();

    show($('gameResult'));

    if(game.end_reason === 'draw' || !game.winner){
      $('gameResultIcon').textContent = '🤝';
      $('gameResultTitle').textContent = 'Égalité !';
      $('gameResultText').textContent = 'Personne ne gagne cette manche.';
    }else if(game.winner === me){
      $('gameResultIcon').textContent = '🏆';
      $('gameResultTitle').textContent = 'VICTOIRE !';
      $('gameResultText').textContent = 'Bien joué, tu as gagné la partie.';
    }else{
      const winner = getGameProfile(game.winner);
      $('gameResultIcon').textContent = '💥';
      $('gameResultTitle').textContent = 'Perdu !';
      $('gameResultText').textContent = `${winner?.username || "Ton ami"} remporte la partie.`;
    }

    $('gameStatus').textContent = game.end_reason === 'abandon' ? 'Partie terminée par abandon' : 'Partie terminée';
  }
}

function renderTicTacToe(){
  const game = state.activeGame;
  const board = boardArray(game);
  const box = $('ticTacToeBoard');
  box.innerHTML = '';

  for(let i=0;i<9;i++){
    const value = board[i] ?? null;
    const btn = document.createElement('button');
    btn.className = 'tttCell' + (value === 'X' ? ' x' : value === 'O' ? ' o' : '');
    btn.textContent = value === 'X' ? '✕' : value === 'O' ? '○' : '';
    btn.disabled =
      game.status !== 'playing' ||
      game.current_turn !== state.session.user.id ||
      !!value ||
      state.gameBusy;

    btn.onclick = ()=>makeGameMove(i);
    box.appendChild(btn);
  }
  show($('ticTacToeWrap'));
}

function renderConnect4(){
  const game = state.activeGame;
  const board = boardArray(game);
  const box = $('connect4Board');
  box.innerHTML = '';

  for(let i=0;i<42;i++){
    const value = board[i] ?? null;
    const col = i % 7;
    const cell = document.createElement('button');
    cell.className = 'c4Cell' +
      (value === 'R' ? ' red' : value === 'Y' ? ' yellow' : '') +
      (game.status==='playing' && game.current_turn===state.session.user.id ? ' playable' : '');
    cell.disabled =
      game.status !== 'playing' ||
      game.current_turn !== state.session.user.id ||
      state.gameBusy;
    cell.onclick = ()=>makeGameMove(col);
    box.appendChild(cell);
  }
  show($('connect4Wrap'));
}

async function chooseGame(type){
  const game = state.activeGame;
  if(!game || game.status !== 'lobby') return;

  const {error} = await sb.rpc('choose_game',{
    game_id:game.id,
    chosen_type:type
  });

  if(error){
    console.error('CHOOSE GAME',error);
    alert("Impossible de lancer ce jeu.");
  }
}

async function makeGameMove(position){
  if(state.gameBusy || !state.activeGame) return;
  state.gameBusy = true;
  renderGame();

  const {error} = await sb.rpc('play_game_move',{
    game_id:state.activeGame.id,
    move_position:position
  });

  state.gameBusy = false;

  if(error){
    console.error('GAME MOVE',error);
    await refreshActiveGame();
  }
}

async function refreshActiveGame(){
  if(!state.activeGame) return;
  const {data} = await sb.from('games').select('*').eq('id',state.activeGame.id).single();
  if(data){
    state.activeGame = data;
    renderGame();
  }
}

async function abandonGame(){
  const game = state.activeGame;
  if(!game || game.status!=='playing') return;
  if(!confirm('Abandonner la partie ? Ton ami gagnera cette manche.')) return;

  const {error} = await sb.rpc('leave_game',{game_id:game.id});
  if(error){
    console.error('LEAVE GAME',error);
    return alert("Impossible de quitter cette partie.");
  }
}

async function replayGame(){
  const game = state.activeGame;
  if(!game) return;

  const {data,error} = await sb.rpc('create_rematch',{old_game_id:game.id});
  if(error){
    console.error('REMATCH',error);
    return alert("Impossible de créer la revanche.");
  }
  await openGame(data);
}

async function startGameVoiceCall(){
  const game = state.activeGame;
  if(!game) return;
  const otherId = gameOtherPlayer(game);
  const other = getGameProfile(otherId) || {username:'Ton ami'};

  if(!window.isSecureContext){
    return alert('Les appels nécessitent la version HTTPS de l’application.');
  }
  if(state.pc || state.groupCallId) return;

  try{
    state.currentCallId = crypto.randomUUID();
    await subscribePrivateCallRoom(state.currentCallId);
    await makePrivatePeer();

    const offer = await state.pc.createOffer();
    await state.pc.setLocalDescription(offer);
    await waitIceComplete(state.pc);

    await sendInbox(otherId,'incoming-call',{
      type:'private',
      game_call:true,
      game_id:game.id,
      call_id:state.currentCallId,
      conversation_id:null,
      from:state.session.user.id,
      username:state.profile.username,
      offer:state.pc.localDescription
    });

    showCallBar(`Jeu avec ${other.username}`,'Sonnerie…');
  }catch(e){
    console.error('GAME CALL',e);
    endAudioCall(false);
    alert("Impossible de démarrer l'appel.");
  }
}

$('chooseTicTacToe').onclick = ()=>chooseGame('morpion');
$('chooseConnect4').onclick = ()=>chooseGame('puissance4');
$('abandonGameBtn').onclick = abandonGame;
$('leaveGameBtn').onclick = closeGameScreen;
$('closeGameBtn').onclick = ()=>{
  if(state.activeGame?.status === 'playing'){
    if(!confirm("Quitter seulement l'écran du jeu ? La partie restera en cours.")) return;
  }
  closeGameScreen();
};
$('replayGameBtn').onclick = replayGame;
$('gameVoiceBtn').onclick = startGameVoiceCall;

function waitIceComplete(pc){
  return new Promise(resolve=>{
    if(pc.iceGatheringState === 'complete') return resolve();
    const done = ()=>{
      if(pc.iceGatheringState === 'complete'){
        pc.removeEventListener('icegatheringstatechange',done);
        resolve();
      }
    };
    pc.addEventListener('icegatheringstatechange',done);
    setTimeout(resolve,4500);
  });
}

function startCallClock(){
  if(state.callClock) clearInterval(state.callClock);
  state.callStartedAt = Date.now();
  state.callClock = setInterval(()=>{
    const seconds = Math.floor((Date.now()-state.callStartedAt)/1000);
    $('callTimer').textContent =
      String(Math.floor(seconds/60)).padStart(2,'0') + ':' +
      String(seconds%60).padStart(2,'0');
  },1000);
}

function showCallBar(label,stateText){
  show($('callBar'));
  $('callName').textContent = label || 'Appel';
  $('callState').textContent = stateText || 'Connexion…';
  if(!state.callStartedAt) startCallClock();
}

async function sendInbox(userId,event,payload){
  const ch = sb.channel('clean4-call-inbox-' + userId);
  await new Promise(resolve=>{
    ch.subscribe(status=>{
      if(status === 'SUBSCRIBED') resolve();
    });
  });
  await ch.send({type:'broadcast',event,payload});
  setTimeout(()=>sb.removeChannel(ch),500);
}

async function makePrivatePeer(){
  state.pc = new RTCPeerConnection({
    iceServers:[
      {urls:'stun:stun.l.google.com:19302'},
      {urls:'stun:stun1.l.google.com:19302'}
    ]
  });

  state.localStream = await navigator.mediaDevices.getUserMedia({
    audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}
  });

  state.localStream.getTracks().forEach(track=>state.pc.addTrack(track,state.localStream));

  state.pc.ontrack = e=>{
    let audio = document.getElementById('remoteCallAudio');
    if(!audio){
      audio = document.createElement('audio');
      audio.id = 'remoteCallAudio';
      audio.autoplay = true;
      audio.playsInline = true;
      document.body.appendChild(audio);
    }
    audio.srcObject = e.streams[0];
    audio.play().catch(()=>{});
  };

  state.pc.onconnectionstatechange = ()=>{
    const status = state.pc?.connectionState;
    if(status === 'connected') $('callState').textContent = 'Appel en cours';
    if(status === 'connecting') $('callState').textContent = 'Connexion…';
    if(['failed','closed'].includes(status)) endAudioCall(false);
  };
}

function subscribePrivateCallRoom(callId){
  return new Promise(resolve=>{
    state.callChannel = sb
      .channel('clean4-call-room-' + callId)
      .on('broadcast',{event:'answer'},async({payload})=>{
        if(!state.pc || !payload?.answer) return;
        await state.pc.setRemoteDescription(payload.answer);
        $('callState').textContent = 'Appel en cours';
      })
      .on('broadcast',{event:'hangup'},()=>endAudioCall(false))
      .on('broadcast',{event:'decline'},()=>{
        alert('Appel refusé.');
        endAudioCall(false);
      })
      .subscribe(status=>{
        if(status === 'SUBSCRIBED') resolve();
      });
  });
}

async function startPrivateCall(){
  const convo = state.activeConversation;
  const other = (state.activeMembers || []).find(m=>m.user_id !== state.session.user.id);
  if(!convo || !other) return;

  try{
    state.currentCallId = crypto.randomUUID();
    await subscribePrivateCallRoom(state.currentCallId);
    await makePrivatePeer();

    const offer = await state.pc.createOffer();
    await state.pc.setLocalDescription(offer);
    await waitIceComplete(state.pc);

    await sendInbox(other.user_id,'incoming-call',{
      type:'private',
      call_id:state.currentCallId,
      conversation_id:convo.id,
      from:state.session.user.id,
      username:state.profile.username,
      offer:state.pc.localDescription
    });

    showCallBar(convo._display?.title || 'Appel','Sonnerie…');
  }catch(e){
    console.error('START PRIVATE CALL',e);
    endAudioCall(false);
    alert('Impossible de démarrer l’appel.');
  }
}

async function ensureGroupPeer(peerId,initiator){
  if(state.groupPeers.has(peerId)) return state.groupPeers.get(peerId);

  const pc = new RTCPeerConnection({
    iceServers:[
      {urls:'stun:stun.l.google.com:19302'},
      {urls:'stun:stun1.l.google.com:19302'}
    ]
  });

  state.localStream.getTracks().forEach(track=>pc.addTrack(track,state.localStream));

  pc.ontrack = e=>{
    let audio = document.getElementById('groupAudio-' + peerId);
    if(!audio){
      audio = document.createElement('audio');
      audio.id = 'groupAudio-' + peerId;
      audio.autoplay = true;
      audio.playsInline = true;
      document.body.appendChild(audio);
    }
    audio.srcObject = e.streams[0];
    audio.play().catch(()=>{});
  };

  pc.onicecandidate = e=>{
    if(e.candidate){
      state.groupCallChannel?.send({
        type:'broadcast',
        event:'ice',
        payload:{
          to:peerId,
          from:state.session.user.id,
          candidate:e.candidate
        }
      });
    }
  };

  state.groupPeers.set(peerId,pc);

  if(initiator){
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);

    await state.groupCallChannel.send({
      type:'broadcast',
      event:'offer',
      payload:{
        to:peerId,
        from:state.session.user.id,
        sdp:pc.localDescription
      }
    });
  }

  return pc;
}

async function joinGroupCall(callId){
  if(state.groupCallId) return;

  state.groupCallId = callId;
  state.localStream = await navigator.mediaDevices.getUserMedia({
    audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}
  });

  state.groupCallChannel = sb.channel(
    'clean4-group-call-' + callId,
    {config:{presence:{key:state.session.user.id}}}
  )
  .on('presence',{event:'sync'},async()=>{
    const presence = state.groupCallChannel.presenceState();
    const peers = Object.keys(presence).filter(id=>id !== state.session.user.id);

    for(const peerId of peers){
      await ensureGroupPeer(peerId,state.session.user.id < peerId);
    }

    $('callState').textContent =
      `${peers.length + 1} participant${peers.length ? 's' : ''}`;
  })
  .on('broadcast',{event:'offer'},async({payload})=>{
    if(payload.to !== state.session.user.id) return;
    const pc = await ensureGroupPeer(payload.from,false);
    await pc.setRemoteDescription(payload.sdp);
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    await state.groupCallChannel.send({
      type:'broadcast',
      event:'answer',
      payload:{
        to:payload.from,
        from:state.session.user.id,
        sdp:pc.localDescription
      }
    });
  })
  .on('broadcast',{event:'answer'},async({payload})=>{
    if(payload.to !== state.session.user.id) return;
    const pc = state.groupPeers.get(payload.from);
    if(pc) await pc.setRemoteDescription(payload.sdp);
  })
  .on('broadcast',{event:'ice'},async({payload})=>{
    if(payload.to !== state.session.user.id) return;
    const pc = state.groupPeers.get(payload.from);
    if(pc){
      try{ await pc.addIceCandidate(payload.candidate); }catch{}
    }
  })
  .on('broadcast',{event:'left'},({payload})=>{
    state.groupPeers.get(payload.from)?.close();
    state.groupPeers.delete(payload.from);
    document.getElementById('groupAudio-' + payload.from)?.remove();
  })
  .subscribe(async status=>{
    if(status === 'SUBSCRIBED'){
      await state.groupCallChannel.track({username:state.profile.username});
    }
  });

  showCallBar(state.activeConversation?._display?.title || 'Groupe','Connexion au groupe…');
}

async function startGroupCall(){
  const convo = state.activeConversation;
  if(!convo) return;

  const callId = crypto.randomUUID();
  await joinGroupCall(callId);

  const others = (state.activeMembers || [])
    .filter(m=>m.user_id !== state.session.user.id);

  for(const member of others){
    await sendInbox(member.user_id,'incoming-call',{
      type:'group',
      call_id:callId,
      conversation_id:convo.id,
      from:state.session.user.id,
      username:state.profile.username
    });
  }
}

async function startAudioCall(){
  if(!state.activeConversation) return;
  if(!window.isSecureContext){
    return alert('Les appels nécessitent la version HTTPS de l’application.');
  }
  if(state.pc || state.groupCallId) return;

  if(state.activeConversation.type === 'group') await startGroupCall();
  else await startPrivateCall();
}

async function receiveIncomingCall(payload){
  if(!payload || payload.from === state.session.user.id) return;
  if(state.pc || state.groupCallId || state.incomingCall) return;

  state.incomingCall = payload;
  $('incomingCallName').textContent =
    `${payload.username || 'Un ami'} vous appelle${payload.type === 'group' ? ' dans le groupe' : ''}`;
  show($('incomingCallModal'));

  try{
    if(navigator.vibrate) navigator.vibrate([350,180,350,180,350]);
  }catch{}
}

$('acceptCallBtn').onclick = async()=>{
  const incoming = state.incomingCall;
  if(!incoming) return;

  hide($('incomingCallModal'));

  try{
    if(!incoming.game_call && incoming.conversation_id){
      await openConversation(incoming.conversation_id);
    }

    if(incoming.type === 'group'){
      state.incomingCall = null;
      await joinGroupCall(incoming.call_id);
      return;
    }

    state.currentCallId = incoming.call_id;
    await subscribePrivateCallRoom(state.currentCallId);
    await makePrivatePeer();
    await state.pc.setRemoteDescription(incoming.offer);

    const answer = await state.pc.createAnswer();
    await state.pc.setLocalDescription(answer);
    await waitIceComplete(state.pc);

    await state.callChannel.send({
      type:'broadcast',
      event:'answer',
      payload:{
        from:state.session.user.id,
        answer:state.pc.localDescription
      }
    });

    state.incomingCall = null;
    showCallBar(
      incoming.game_call
        ? `Jeu avec ${incoming.username || 'un ami'}`
        : (state.activeConversation?._display?.title || 'Appel'),
      'Appel en cours'
    );
  }catch(e){
    console.error('ACCEPT CALL',e);
    state.incomingCall = null;
    endAudioCall(false);
    alert('Impossible d’accepter l’appel.');
  }
};

$('declineCallBtn').onclick = async()=>{
  const incoming = state.incomingCall;
  hide($('incomingCallModal'));

  if(incoming?.type === 'private' && incoming.call_id){
    const ch = sb.channel('clean4-call-room-' + incoming.call_id);
    await new Promise(resolve=>{
      ch.subscribe(status=>{
        if(status === 'SUBSCRIBED') resolve();
      });
    });
    await ch.send({
      type:'broadcast',
      event:'decline',
      payload:{from:state.session.user.id}
    });
    sb.removeChannel(ch);
  }

  state.incomingCall = null;
};

function endAudioCall(send=true){
  if(state.groupCallId){
    state.groupCallChannel?.send({
      type:'broadcast',
      event:'left',
      payload:{from:state.session.user.id}
    });

    state.groupPeers.forEach(pc=>pc.close());
    state.groupPeers.clear();

    if(state.groupCallChannel) sb.removeChannel(state.groupCallChannel);
    state.groupCallChannel = null;
    state.groupCallId = null;

    document.querySelectorAll('audio[id^="groupAudio-"]').forEach(a=>a.remove());
  }else{
    if(send && state.callChannel){
      state.callChannel.send({
        type:'broadcast',
        event:'hangup',
        payload:{from:state.session.user.id}
      });
    }

    state.pc?.close();
    state.pc = null;

    if(state.callChannel) sb.removeChannel(state.callChannel);
    state.callChannel = null;
    state.currentCallId = null;

    document.getElementById('remoteCallAudio')?.remove();
  }

  state.localStream?.getTracks().forEach(t=>t.stop());
  state.localStream = null;

  clearInterval(state.callClock);
  state.callClock = null;
  state.callStartedAt = 0;
  state.muted = false;

  hide($('callBar'));
  $('callTimer').textContent = '00:00';
  $('muteCallBtn').textContent = '🎙️';
}

$('audioCallBtn').onclick = startAudioCall;
$('hangupCallBtn').onclick = ()=>endAudioCall(true);
$('muteCallBtn').onclick = ()=>{
  state.muted = !state.muted;
  state.localStream?.getAudioTracks().forEach(track=>track.enabled = !state.muted);
  $('muteCallBtn').textContent = state.muted ? '🔇' : '🎙️';
  $('callState').textContent = state.muted ? 'Micro coupé' : 'Appel en cours';
};

$('backBtn').onclick = () => $('chat').classList.remove('open');

window.addEventListener('focus',async()=>{
  if(!state.session) return;
  await loadFriendRequests();
  await loadFriends();
  await loadConversations();
  await loadGameInvites();
  renderGameFriends();
});

document.addEventListener('visibilitychange',async()=>{
  if(document.visibilityState !== 'visible' || !state.session) return;

  await loadFriendRequests();
  await loadFriends();
  await loadConversations();

  if(state.activeConversation) await loadMessages();
});

setupTabs();
renderRememberedAccounts();
boot();

if('serviceWorker' in navigator){
  window.addEventListener('load',()=>{
    navigator.serviceWorker.register('/service-worker.js').catch(console.error);
  });
}
})();