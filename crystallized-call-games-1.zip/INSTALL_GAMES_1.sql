-- CRYSTALLIZED CALL — GAMES 1
-- À exécuter UNE SEULE FOIS dans Supabase > SQL Editor > New query > Run.
-- Ajoute les invitations de jeu + Morpion + Puissance 4 multijoueur.
-- Ne supprime aucun compte, ami, message ou groupe.

create table if not exists public.games (
  id uuid primary key default gen_random_uuid(),
  player1 uuid not null references auth.users(id) on delete cascade,
  player2 uuid not null references auth.users(id) on delete cascade,
  game_type text check (game_type in ('morpion','puissance4')),
  board jsonb not null default '[]'::jsonb,
  current_turn uuid references auth.users(id) on delete set null,
  status text not null default 'lobby' check (status in ('lobby','playing','finished')),
  winner uuid references auth.users(id) on delete set null,
  end_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.game_invites (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references auth.users(id) on delete cascade,
  receiver_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','rejected')),
  game_id uuid references public.games(id) on delete set null,
  created_at timestamptz not null default now(),
  responded_at timestamptz
);

create unique index if not exists one_pending_game_invite
on public.game_invites(sender_id,receiver_id)
where status='pending';

alter table public.games enable row level security;
alter table public.game_invites enable row level security;

drop policy if exists games_players_read on public.games;
create policy games_players_read on public.games
for select to authenticated
using(auth.uid()=player1 or auth.uid()=player2);

drop policy if exists game_invites_people_read on public.game_invites;
create policy game_invites_people_read on public.game_invites
for select to authenticated
using(auth.uid()=sender_id or auth.uid()=receiver_id);

grant select on public.games to authenticated;
grant select on public.game_invites to authenticated;

-- Invitation : uniquement entre amis.
create or replace function public.create_game_invite(other_user_id uuid)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  iid uuid;
begin
  if auth.uid() is null then raise exception 'Non connecté'; end if;
  if other_user_id=auth.uid() then raise exception 'Utilisateur invalide'; end if;

  if not exists(
    select 1 from public.friendships
    where user_one=least(auth.uid(),other_user_id)
      and user_two=greatest(auth.uid(),other_user_id)
  ) then
    raise exception 'Vous devez être amis';
  end if;

  select id into iid
  from public.game_invites
  where sender_id=auth.uid()
    and receiver_id=other_user_id
    and status='pending'
  order by created_at desc
  limit 1;

  if iid is null then
    insert into public.game_invites(sender_id,receiver_id)
    values(auth.uid(),other_user_id)
    returning id into iid;
  end if;

  return iid;
end;
$$;

grant execute on function public.create_game_invite(uuid) to authenticated;

create or replace function public.accept_game_invite(invite_id uuid)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  inv public.game_invites%rowtype;
  gid uuid;
begin
  select * into inv
  from public.game_invites
  where id=invite_id
  for update;

  if inv.id is null then raise exception 'Invitation introuvable'; end if;
  if inv.receiver_id<>auth.uid() then raise exception 'Non autorisé'; end if;

  if inv.status='accepted' and inv.game_id is not null then
    return inv.game_id;
  end if;

  if inv.status<>'pending' then raise exception 'Invitation terminée'; end if;

  insert into public.games(player1,player2,current_turn,status)
  values(inv.sender_id,inv.receiver_id,inv.sender_id,'lobby')
  returning id into gid;

  update public.game_invites
  set status='accepted',game_id=gid,responded_at=now()
  where id=invite_id;

  return gid;
end;
$$;

grant execute on function public.accept_game_invite(uuid) to authenticated;

create or replace function public.reject_game_invite(invite_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  update public.game_invites
  set status='rejected',responded_at=now()
  where id=invite_id
    and receiver_id=auth.uid()
    and status='pending';
end;
$$;

grant execute on function public.reject_game_invite(uuid) to authenticated;

create or replace function public.choose_game(game_id uuid, chosen_type text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  g public.games%rowtype;
  initial_board jsonb;
begin
  if chosen_type not in ('morpion','puissance4') then
    raise exception 'Jeu invalide';
  end if;

  select * into g from public.games where id=game_id for update;
  if g.id is null then raise exception 'Partie introuvable'; end if;
  if auth.uid() not in (g.player1,g.player2) then raise exception 'Non autorisé'; end if;
  if g.status<>'lobby' then raise exception 'Partie déjà commencée'; end if;

  if chosen_type='morpion' then
    initial_board='[null,null,null,null,null,null,null,null,null]'::jsonb;
  else
    initial_board='[
      null,null,null,null,null,null,null,
      null,null,null,null,null,null,null,
      null,null,null,null,null,null,null,
      null,null,null,null,null,null,null,
      null,null,null,null,null,null,null,
      null,null,null,null,null,null,null
    ]'::jsonb;
  end if;

  update public.games
  set game_type=chosen_type,
      board=initial_board,
      current_turn=player1,
      status='playing',
      winner=null,
      end_reason=null,
      updated_at=now()
  where id=game_id;
end;
$$;

grant execute on function public.choose_game(uuid,text) to authenticated;

create or replace function public.play_game_move(game_id uuid, move_position integer)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  g public.games%rowtype;
  b jsonb;
  mark text;
  other_player uuid;
  i integer;
  r integer;
  c integer;
  idx integer;
  won boolean := false;
  full_board boolean := true;
begin
  select * into g from public.games where id=game_id for update;

  if g.id is null then raise exception 'Partie introuvable'; end if;
  if g.status<>'playing' then raise exception 'Partie terminée'; end if;
  if auth.uid()<>g.current_turn then raise exception 'Pas votre tour'; end if;
  if auth.uid() not in (g.player1,g.player2) then raise exception 'Non autorisé'; end if;

  b:=g.board;
  other_player:=case when auth.uid()=g.player1 then g.player2 else g.player1 end;

  if g.game_type='morpion' then
    if move_position<0 or move_position>8 then raise exception 'Case invalide'; end if;
    if (b->move_position) is distinct from 'null'::jsonb then raise exception 'Case occupée'; end if;

    mark:=case when auth.uid()=g.player1 then 'X' else 'O' end;
    b:=jsonb_set(b,array[move_position::text],to_jsonb(mark),false);

    won :=
      ((b->>0)=mark and (b->>1)=mark and (b->>2)=mark) or
      ((b->>3)=mark and (b->>4)=mark and (b->>5)=mark) or
      ((b->>6)=mark and (b->>7)=mark and (b->>8)=mark) or
      ((b->>0)=mark and (b->>3)=mark and (b->>6)=mark) or
      ((b->>1)=mark and (b->>4)=mark and (b->>7)=mark) or
      ((b->>2)=mark and (b->>5)=mark and (b->>8)=mark) or
      ((b->>0)=mark and (b->>4)=mark and (b->>8)=mark) or
      ((b->>2)=mark and (b->>4)=mark and (b->>6)=mark);

  elsif g.game_type='puissance4' then
    if move_position<0 or move_position>6 then raise exception 'Colonne invalide'; end if;

    idx:=-1;
    for r in reverse 0..5 loop
      i:=r*7+move_position;
      if (b->i) is not distinct from 'null'::jsonb then
        idx:=i;
        exit;
      end if;
    end loop;

    if idx<0 then raise exception 'Colonne pleine'; end if;

    mark:=case when auth.uid()=g.player1 then 'R' else 'Y' end;
    b:=jsonb_set(b,array[idx::text],to_jsonb(mark),false);

    -- horizontal
    for r in 0..5 loop
      for c in 0..3 loop
        if (b->>(r*7+c))=mark
           and (b->>(r*7+c+1))=mark
           and (b->>(r*7+c+2))=mark
           and (b->>(r*7+c+3))=mark then
          won:=true;
        end if;
      end loop;
    end loop;

    -- vertical
    if not won then
      for r in 0..2 loop
        for c in 0..6 loop
          if (b->>(r*7+c))=mark
             and (b->>((r+1)*7+c))=mark
             and (b->>((r+2)*7+c))=mark
             and (b->>((r+3)*7+c))=mark then
            won:=true;
          end if;
        end loop;
      end loop;
    end if;

    -- diagonale \
    if not won then
      for r in 0..2 loop
        for c in 0..3 loop
          if (b->>(r*7+c))=mark
             and (b->>((r+1)*7+c+1))=mark
             and (b->>((r+2)*7+c+2))=mark
             and (b->>((r+3)*7+c+3))=mark then
            won:=true;
          end if;
        end loop;
      end loop;
    end if;

    -- diagonale /
    if not won then
      for r in 0..2 loop
        for c in 3..6 loop
          if (b->>(r*7+c))=mark
             and (b->>((r+1)*7+c-1))=mark
             and (b->>((r+2)*7+c-2))=mark
             and (b->>((r+3)*7+c-3))=mark then
            won:=true;
          end if;
        end loop;
      end loop;
    end if;
  else
    raise exception 'Jeu non choisi';
  end if;

  for i in 0..jsonb_array_length(b)-1 loop
    if (b->i) is not distinct from 'null'::jsonb then
      full_board:=false;
      exit;
    end if;
  end loop;

  if won then
    update public.games
    set board=b,
        status='finished',
        winner=auth.uid(),
        end_reason='win',
        current_turn=null,
        updated_at=now()
    where id=game_id;
  elsif full_board then
    update public.games
    set board=b,
        status='finished',
        winner=null,
        end_reason='draw',
        current_turn=null,
        updated_at=now()
    where id=game_id;
  else
    update public.games
    set board=b,
        current_turn=other_player,
        updated_at=now()
    where id=game_id;
  end if;
end;
$$;

grant execute on function public.play_game_move(uuid,integer) to authenticated;

create or replace function public.leave_game(game_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  g public.games%rowtype;
  other_player uuid;
begin
  select * into g from public.games where id=game_id for update;
  if g.id is null then raise exception 'Partie introuvable'; end if;
  if auth.uid() not in (g.player1,g.player2) then raise exception 'Non autorisé'; end if;
  if g.status='finished' then return; end if;

  other_player:=case when auth.uid()=g.player1 then g.player2 else g.player1 end;

  update public.games
  set status='finished',
      winner=other_player,
      end_reason='abandon',
      current_turn=null,
      updated_at=now()
  where id=game_id;
end;
$$;

grant execute on function public.leave_game(uuid) to authenticated;

create or replace function public.create_rematch(old_game_id uuid)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  g public.games%rowtype;
  gid uuid;
begin
  select * into g from public.games where id=old_game_id;
  if g.id is null then raise exception 'Partie introuvable'; end if;
  if auth.uid() not in (g.player1,g.player2) then raise exception 'Non autorisé'; end if;

  insert into public.games(player1,player2,current_turn,status)
  values(g.player2,g.player1,g.player2,'lobby')
  returning id into gid;

  return gid;
end;
$$;

grant execute on function public.create_rematch(uuid) to authenticated;

-- Realtime
do $$ begin
  alter publication supabase_realtime add table public.games;
exception when duplicate_object then null; end $$;

do $$ begin
  alter publication supabase_realtime add table public.game_invites;
exception when duplicate_object then null; end $$;

alter table public.games replica identity full;
alter table public.game_invites replica identity full;

select 'CRYSTALLIZED CALL GAMES 1 PRET' as resultat;
