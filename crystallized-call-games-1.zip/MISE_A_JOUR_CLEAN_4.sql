-- CRYSTALLIZED CALL CLEAN 4
-- À exécuter UNE SEULE FOIS dans Supabase > SQL Editor > New query > Run.
-- Répare Quitter/Supprimer un groupe et remet le stockage des images/vocaux.

-- Colonnes médias
alter table public.messages add column if not exists message_type text default 'text';
alter table public.messages add column if not exists media_url text;
alter table public.messages add column if not exists duration_seconds integer;
alter table public.messages add column if not exists edited_at timestamptz;
alter table public.messages add column if not exists deleted_at timestamptz;

-- Stockage images/vocaux
insert into storage.buckets(id,name,public)
values('chat-media','chat-media',true)
on conflict(id) do update set public=true;

drop policy if exists "Clean4 chat media upload" on storage.objects;
create policy "Clean4 chat media upload"
on storage.objects for insert to authenticated
with check(
  bucket_id='chat-media'
  and (storage.foldername(name))[1]=auth.uid()::text
);

drop policy if exists "Clean4 chat media read" on storage.objects;
create policy "Clean4 chat media read"
on storage.objects for select to authenticated
using(bucket_id='chat-media');

drop policy if exists "Clean4 chat media public read" on storage.objects;
create policy "Clean4 chat media public read"
on storage.objects for select to public
using(bucket_id='chat-media');

-- Quitter un groupe : ne dépend pas des anciennes versions.
create or replace function public.leave_group(group_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  me uuid := auth.uid();
  replacement uuid;
begin
  if me is null then raise exception 'Non connecté'; end if;

  if not exists(
    select 1 from public.conversation_members
    where conversation_id=group_id and user_id=me
  ) then
    raise exception 'Pas membre';
  end if;

  -- Si je suis propriétaire/créateur, transférer la propriété à un autre membre.
  if exists(
    select 1 from public.conversation_members
    where conversation_id=group_id and user_id=me and role='owner'
  ) or exists(
    select 1 from public.conversations
    where id=group_id and created_by=me
  ) then
    select user_id into replacement
    from public.conversation_members
    where conversation_id=group_id and user_id<>me
    order by user_id
    limit 1;

    if replacement is null then
      -- Dernier membre : on supprime le groupe.
      perform public.delete_group(group_id);
      return;
    end if;

    update public.conversation_members
    set role='owner'
    where conversation_id=group_id and user_id=replacement;

    update public.conversations
    set created_by=replacement
    where id=group_id and created_by=me;
  end if;

  delete from public.conversation_members
  where conversation_id=group_id and user_id=me;
end;
$$;

grant execute on function public.leave_group(uuid) to authenticated;

-- Suppression complète d'un groupe.
create or replace function public.delete_group(group_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  me uuid := auth.uid();
begin
  if me is null then raise exception 'Non connecté'; end if;

  if not (
    exists(
      select 1 from public.conversations
      where id=group_id and type='group' and created_by=me
    )
    or exists(
      select 1 from public.conversation_members
      where conversation_id=group_id and user_id=me and role='owner'
    )
  ) then
    raise exception 'Non autorisé';
  end if;

  -- Anciennes tables d'appels, si elles existent.
  if to_regclass('public.call_participants') is not null
     and to_regclass('public.active_calls') is not null then
    execute 'delete from public.call_participants
             where call_id in (select id from public.active_calls where conversation_id=$1)'
      using group_id;
  end if;

  if to_regclass('public.active_calls') is not null then
    execute 'delete from public.active_calls where conversation_id=$1'
      using group_id;
  end if;

  if to_regclass('public.message_reads') is not null then
    execute 'delete from public.message_reads
             where message_id in (select id from public.messages where conversation_id=$1)'
      using group_id;
  end if;

  delete from public.messages where conversation_id=group_id;
  delete from public.conversation_members where conversation_id=group_id;
  delete from public.conversations where id=group_id and type='group';
end;
$$;

grant execute on function public.delete_group(uuid) to authenticated;

-- Nettoyage des anciens groupes portant exactement le même nom normalisé.
do $$
declare r record;
begin
  for r in
    select id
    from (
      select id,
             row_number() over(
               partition by lower(regexp_replace(trim(coalesce(name,'')), '\s+', ' ', 'g'))
               order by created_at asc, id asc
             ) rn
      from public.conversations
      where type='group'
    ) x
    where rn>1
  loop
    -- Suppression sécurisée des vieux doublons, même s'ils ont été créés par une ancienne version.
    if to_regclass('public.call_participants') is not null
       and to_regclass('public.active_calls') is not null then
      execute 'delete from public.call_participants
               where call_id in (select id from public.active_calls where conversation_id=$1)'
        using r.id;
    end if;

    if to_regclass('public.active_calls') is not null then
      execute 'delete from public.active_calls where conversation_id=$1'
        using r.id;
    end if;

    if to_regclass('public.message_reads') is not null then
      execute 'delete from public.message_reads
               where message_id in (select id from public.messages where conversation_id=$1)'
        using r.id;
    end if;

    delete from public.messages where conversation_id=r.id;
    delete from public.conversation_members where conversation_id=r.id;
    delete from public.conversations where id=r.id;
  end loop;
end $$;

drop index if exists public.conversations_unique_group_name_normalized;
create unique index conversations_unique_group_name_normalized
on public.conversations(
  lower(regexp_replace(trim(coalesce(name,'')), '\s+', ' ', 'g'))
)
where type='group';

select 'CLEAN 4 PRET' as resultat;
